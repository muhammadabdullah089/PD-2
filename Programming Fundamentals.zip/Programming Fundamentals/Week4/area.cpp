#include<iostream>
using namespace std;
main()
{


   int length;
   int width;
   int area;
   cout<<"Enter the length of rectangle: ";
   cin>>length;
   cout<<"Enter the width of rectangle: ";
   cin>>width;
   area=length*width;
   cout<<"The area of the rectangle is: " <<area;
  
}


