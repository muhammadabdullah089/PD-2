#include<iostream>
using namespace std;
main()
{

   int currentWorldPopulation;
   int monthlyBirthRate;
   int monthsUntilSpaceship;
   int population;
   cout<<"Enter current world population: ";
   cin>>currentWorldPopulation;
   cout<<"Enter monthlyBirthRate: ";
   cin>>monthlyBirthRate;
   cout<<"Enter months until spaceship: ";
   cin>>monthsUntilSpaceship;
   population=currentWorldPopulation+(monthlyBirthRate*monthsUntilSpaceship);
   cout<<"The population in three decades will be: " <<population;

}