#include<iostream>
using namespace std;
main()
{

   int wins;
   int draws;
   int losses;
   int noOfPoints;
   cout<<"Enter the number of wins: ";
   cin>>wins;
   cout<<"Enter the number of draws: ";
   cin>>draws;
   cout<<"Enter the number of losses: ";
   cin>>losses;
   noOfPoints=2*wins+2*draws+2*losses;
   cout<<"Pakistan has obtained points in asia cup tournament: " <<noOfPoints;

}
   