#include<iostream>
using namespace std;
main()
{


   int seconds;
   int hours;
   cout<<"Enter hours: ";
   cin>>hours;
   seconds=hours*60*60;
   cout<<"Hours is eqiuvalent to: " <<seconds;
 }