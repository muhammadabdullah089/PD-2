#include<iostream>
using namespace std;
main()
{


   int days;
   float dollars;
   float exchangeRate;
   float salaryPerMonth;
   float salaryPerYear;
   float salaryAfterBonus;
   float salaryAfterTax;
   float earningPerDayInRps;
   cout<<"Enter working days per month:";
   cin>>days;
   cout<<"Enter earned dollars per day:";
   cin>>dollars;
   cout<<"Enter exchange rate from USD to PKR:";
   cin>>exchangeRate;
   salaryPerMonth=days*dollars;
   salaryPerYear=salaryPerMonth*12;
   salaryAfterBonus=salaryPerYear+(salaryPerMonth*2.5);
   salaryAfterTax=salaryAfterBonus-(salaryAfterBonus*25/100);
   earningPerDayInRps=(salaryAfterTax*exchangeRate)/365;
   cout<<"Averge earnings per day: "<<earningPerDayInRps;

}
   