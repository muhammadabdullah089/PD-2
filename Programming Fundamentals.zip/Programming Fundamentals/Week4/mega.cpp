#include<iostream>
using namespace std;
main()
{
  
    int bits;
    int megabytes;
    cout<<"Enter megabytes: ";
    cin>>megabytes;
    bits=megabytes*1024*8;
    cout<<"MB is equivalent to: " <<bits;


    
  

   
   
    
}

    
 