#include<iostream>
using namespace std;
main()
{


    int days;
    int years;
    cout<<"Enter years: ";
    cin>>years;
    days=years*365;
    cout<<"Your age in days is approximately: " <<days;
}